export let cart= JSON.parse(localStorage.getItem("carts")) || [];
export function storelocally(){
    localStorage.setItem("carts",JSON.stringify(cart));
}
export function addToCart(productId){
    let matchingitems;
    
    cart.forEach((cartitems)=>{
       
     
     if(cartitems.productId===productId){
       matchingitems=cartitems;
 
     };
    
   });
   if(matchingitems){
     matchingitems.quantity+=1;
 
   
   }
   else{
     cart.push({
       productId:productId,
       quantity:1,
            
     });
     
   }
   storelocally();
}

export function removeProduct(productId){
 let newitem=[];
 cart.forEach((cartItem)=>{
//     cart ko                delete ko
    if(cartItem.productId!== productId){
    newitem.push(cartItem);
    }
    
 });
 cart= newitem;
 storelocally();
}